using System;
using System.Collections.Generic;
using System.Linq;



using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace WindowsGame2
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Texture2D TestPic;
        Texture2D Cursor;
        Texture2D texture;
        Texture2D Data_Texture;  // texture to hold the average data for the shader 



        Vector2 playerPos = new Vector2(0, 0);
        Vector2 CursorPos = new Vector2(0, 0);
       // float cursor_x;  //cursor position to pass tot he shader..
       // float cursor_y;
        float blur_radius = 200.0f; // blur diameter to pass to the shader 

        MouseState ms;
       // Rectangle bounds;
        int w;
        int h;
        Effect Testeffect;
       




        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferHeight = 768;
            graphics.PreferredBackBufferWidth = 1024;
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
          

            // TODO: use this.Content to load your game content here

            TestPic = Content.Load<Texture2D>("spots");
            Cursor = Content.Load<Texture2D>("TestPic");
            Testeffect = Content.Load<Effect>("Effect1");


      
          


        }

      



        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();


            int Data_Texture_Size = 200;

            Vector2[] pass_texture = new Vector2[Data_Texture_Size];


            for (int i = 1; i < Data_Texture_Size; i++)
            {
                pass_texture[i].X = (float)i / GraphicsDevice.PresentationParameters.BackBufferWidth;
                pass_texture[i].Y = (float)i / GraphicsDevice.PresentationParameters.BackBufferHeight;
            }


            Data_Texture = new Texture2D(GraphicsDevice, Data_Texture_Size, 1, false, SurfaceFormat.Vector2);
            Data_Texture.SetData<Vector2>(pass_texture, 0, Data_Texture_Size);


            // TODO: Add your update logic here
            ms = Mouse.GetState();
            base.Update(gameTime);
        }

        private struct Rect
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {

       
            Rectangle rectangle;
            rectangle.Height=75;     
            rectangle.Width=75;

           
                   
            float mouse_x = (float)ms.X/GraphicsDevice.PresentationParameters.BackBufferWidth;
            float mouse_y = (float)ms.Y/GraphicsDevice.PresentationParameters.BackBufferHeight;

            int[] backbuffer = new int[GraphicsDevice.PresentationParameters.BackBufferWidth * GraphicsDevice.PresentationParameters.BackBufferHeight];
             
            CursorPos.X = ms.X;
            CursorPos.Y = ms.Y;
            rectangle.X = ms.X;
            rectangle.Y = ms.Y;

            Testeffect.Parameters["blur_radius"].SetValue(blur_radius);
            Testeffect.Parameters["cursor_x"].SetValue(mouse_x);
            Testeffect.Parameters["cursor_y"].SetValue(mouse_y);


            spriteBatch.Begin();
            spriteBatch.Draw(TestPic, playerPos, Color.White);
            spriteBatch.End();

          
//            //copy the backbuffer to the texture
//            GraphicsDevice.GetBackBufferData(backbuffer);
//            texture = new Texture2D(GraphicsDevice, GraphicsDevice.PresentationParameters.BackBufferWidth, GraphicsDevice.PresentationParameters.BackBufferHeight, false, GraphicsDevice.PresentationParameters.BackBufferFormat);
//            texture.SetData(backbuffer);
         
////
        //    spriteBatch.Begin();
       //     spriteBatch.Draw(Cursor, playerPos, Color.White);
        //    spriteBatch.End();
                
           // GraphicsDevice.Textures[0] = Data_Texture;   // texure to pass variables to the shader
          //  GraphicsDevice.Textures[1] = Cursor;
            

            spriteBatch.Begin(SpriteSortMode.Immediate, BlendState.AlphaBlend, null, null, null, Testeffect);
            spriteBatch.Draw(TestPic, playerPos, Color.White); 
            spriteBatch.End();

       
            base.Draw(gameTime);
        }
    }
}
